"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CommentApi = "comment";
//# sourceMappingURL=comments.js.map