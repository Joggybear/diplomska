"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tyx_1 = require("tyx");
exports.ConfigApi = tyx_1.Configuration;
//# sourceMappingURL=config.js.map