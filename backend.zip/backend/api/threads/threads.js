"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ThreadApi = "thread";
//# sourceMappingURL=threads.js.map