"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tyx_1 = require("tyx");
const config_1 = require("../services/config");
class AwsContainer extends tyx_1.LambdaContainer {
    constructor(config) {
        super('TINO');
        this.register(config_1.ConfigService, config);
    }
}
exports.AwsContainer = AwsContainer;
//# sourceMappingURL=aws.js.map