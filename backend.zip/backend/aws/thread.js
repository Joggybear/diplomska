"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_1 = require("./aws");
const services_1 = require("../services");
exports.container = new aws_1.AwsContainer()
    .publish(services_1.ThreadService);
exports.lambda = exports.container.export();
//# sourceMappingURL=thread.js.map