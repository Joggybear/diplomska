"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const AWS = require("aws-sdk");
var credentials = new AWS.SharedIniFileCredentials({ profile: 'personal' });
AWS.config.credentials = credentials;
AWS.config.region = "eu-west-1";
exports.Config = {
    STAGE: "diplomska-dev",
};
//# sourceMappingURL=dev.env.js.map