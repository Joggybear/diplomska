"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tyx_1 = require("tyx");
const services_1 = require("../services");
const dev_env_1 = require("./dev.env");
let exp = new tyx_1.ExpressContainer('TINO')
    .register(services_1.ConfigService, dev_env_1.Config)
    .publish(services_1.ThreadService)
    .publish(services_1.CommentService);
exp.start(5055);
//# sourceMappingURL=main.js.map