"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tyx_1 = require("tyx");
const aws_sdk_1 = require("aws-sdk");
const Marshaler = require("dynamodb-marshaler");
class SchemaError extends tyx_1.InternalServerError {
    constructor(path, message) {
        super(`Invalid schema [${path}]: ${message}`);
    }
}
exports.SchemaError = SchemaError;
class MarshalError extends tyx_1.InternalServerError {
    constructor(path, message) {
        super(`Invalid object [${path}]: ${message}`);
    }
}
exports.MarshalError = MarshalError;
class Repository {
    constructor(stage, table, schema) {
        this.db = new aws_sdk_1.DynamoDB();
        this.log = tyx_1.Logger.get("dynamo", this);
        this.stage = stage;
        this.table = table;
        this.tableName = stage + "-" + table;
        try {
            this.schema = JSON.parse(JSON.stringify(schema));
            Object.assign(this.schema, {
                Version: { N: true },
                Created: { S: true },
                Updated: { S: false },
                Deleted: { BOOL: false }
            });
        }
        catch (e) {
            throw new SchemaError("", "Schema must be valid JSON");
        }
        let keys = Repository.validate(this.schema);
        this.hashKey = keys.hash;
        this.rangeKey = keys.range;
    }
    marshal(json) {
        return Repository.marshal(this.schema, json);
    }
    unmarshal(data) {
        return Repository.unmarshal(this.schema, data);
    }
    static nextVer() {
        return Date.now() * 10000 + Math.floor((process.hrtime()[1] % 1000000) / 100);
    }
    _load(hash, range) {
        return __awaiter(this, void 0, void 0, function* () {
            // http://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/DynamoDB.html#getItem-property
            let key = {};
            key[this.hashKey.name] = { [this.hashKey.type]: hash };
            if (this.rangeKey)
                key[this.rangeKey.name] = { [this.rangeKey.type]: range };
            console.log('KEY = ', key);
            console.log('HASH = ', hash);
            console.log('RANGE = ', range);
            console.log('TABLE NAME = ', this.tableName);
            console.log("SCHEMA = ", this.schema);
            let res = yield this.db.getItem({
                TableName: this.tableName,
                Key: key,
            }).promise();
            let item = res && res.Item;
            console.log('ITEM = ', item);
            if (!item)
                throw new tyx_1.NotFound(this.rangeKey
                    ? `${this.table} Hash: [${hash}], Range: [${range}] not found`
                    : `${this.table} Hash: [${hash}] not found`);
            let result = this.unmarshal(res.Item);
            return result;
        });
    }
    _save(json) {
        return __awaiter(this, void 0, void 0, function* () {
            // TODO: Version check and update timestamp
            if (!json.version) {
                json.created = new Date().toISOString();
                json.updated = null;
            }
            else {
                json.updated = new Date().toISOString();
            }
            json.version = Repository.nextVer();
            let item = this.marshal(json);
            // TODO: Check keys are not null
            let res = yield this.db.putItem({
                TableName: this.tableName,
                // TODO: Version check
                Item: item
            }).promise();
            return res;
        });
    }
    _delete(json) {
        return __awaiter(this, void 0, void 0, function* () {
            let hash = json[this.hashKey.def.map];
            let range = (this.rangeKey) ? json[this.rangeKey.def.map] : undefined;
            // TODO: Check version
            // let version = json.version;
            let key;
            if (this.rangeKey) {
                key = {
                    [this.hashKey.name]: { [this.hashKey.type]: hash },
                    [this.rangeKey.name]: { [this.rangeKey.type]: range }
                };
            }
            else {
                key = { [this.hashKey.name]: { [this.hashKey.type]: hash } };
            }
            let res = yield this.db.deleteItem({
                TableName: this.tableName,
                Key: key,
                ReturnValues: "ALL_OLD"
            }).promise();
            return res;
        });
    }
    // ==== Static ===========================================================
    // TODO: Types for dynamo object
    static marshal(schema, json, data) {
        data = data || {};
        // TODO: Optional params
        // Check for required ...
        // Type check, e.g. string for num or bool
        for (let name in schema) {
            let field = schema[name];
            let type = field["$type"];
            let path = field["$jpath"];
            let def = field[type];
            let value = json[def.map];
            if (value === "")
                value = null;
            let result = value;
            if (def.req && !value && value !== false && value !== 0)
                throw new MarshalError(path, `Required property missing value [${value}]`);
            // Skip properties that are not part of the input
            if (!def.req && value === undefined)
                continue;
            if (type === "M" && value) {
                result = Repository.marshal(def.schema, value, {});
                result = { M: result };
            }
            else if (type === "M" && !value) {
                result = { NULL: true };
            }
            else {
                result = Marshaler.marshal(value);
            }
            let resType = Object.keys(result)[0];
            let expType = type; // type === "ANY" ? "ANY" : type;
            // let resVal = result[expType];
            if (expType !== "ANY" && expType !== resType && resType !== "NULL")
                throw new MarshalError(path, `Type mismatch, expexted [${type}] found [${resType}]`);
            // TODO: Type conversion ????
            // TODO: List all exceptions ..... ????
            data[name] = result;
        }
        return data;
    }
    static unmarshal(schema, data, json) {
        json = json || {};
        // TODO: Optional params
        // Check for required ...
        // Type check, e.g. string for num or bool
        for (let name in schema) {
            let value = data[name];
            if (value === undefined)
                continue;
            let field = schema[name];
            let type = field["$type"];
            // let path: string = field["$spath"];
            let def = field[type];
            let map = def.map;
            if (type === "M" && value[type]) {
                value = Repository.unmarshal(def.schema, value[type], {});
                json[map] = value;
                continue;
            }
            value = Marshaler.unmarshal(value);
            // TODO Check constraints ....
            json[map] = value;
        }
        return json;
    }
    static validate(schema, schemaPath, jsonPath) {
        let hash;
        let range;
        for (let name in schema) {
            let spath = schemaPath ? schemaPath + "." + name : name;
            let field = schema[name];
            let keys = Object.getOwnPropertyNames(field);
            if (keys.length !== 1)
                throw new SchemaError(spath, "Single attribute expected");
            let type = keys[0];
            switch (type) {
                case "S":
                case "N":
                case "BOOL":
                case "NULL":
                case "M":
                case "ANY":
                    break;
                default: throw new SchemaError(spath, `Unknown type [${type}]`);
            }
            let def = field[type];
            if (type !== "M" && def === true)
                def = { map: null, req: true };
            else if (type !== "M" && def === false)
                def = { map: null, req: false };
            else if (type !== "M" && typeof def === "string")
                def = { map: def, req: true };
            else if (type === "M" && typeof def !== "object")
                new SchemaError(spath, "Object defintion expected");
            else if (type === "M" && !def.schema)
                def = { map: null, req: true, schema: def };
            if (!def.map)
                def.map = name.substring(0, 1).toLowerCase() + name.substring(1);
            if (def.req === undefined)
                def.req = true;
            field[type] = def;
            let jpath = jsonPath ? jsonPath + "." + def.map : def.map;
            // Hidden helper property
            Object.defineProperty(field, "$type", { enumerable: false, value: type });
            Object.defineProperty(field, "$spath", { enumerable: false, value: spath });
            Object.defineProperty(field, "$jpath", { enumerable: false, value: jpath });
            if (type === "S" || type === "N") {
                if (def.hash) {
                    def.req = true;
                    if (schemaPath)
                        throw new SchemaError(spath, "HASH key definition allowed on top level only");
                    if (hash)
                        throw new SchemaError(spath, "Duplicate HASH key definition");
                    hash = { name, type, def };
                }
                if (def.range) {
                    def.req = true;
                    if (schemaPath)
                        throw new SchemaError(spath, "RANGE key definition allowed on top level only");
                    if (range)
                        throw new SchemaError(spath, "Duplicate RANGE key definition");
                    range = { name, type, def };
                }
            }
            if (def.schema)
                Repository.validate(def.schema, spath, jpath);
        }
        if (schemaPath)
            return undefined;
        if (!hash)
            throw new SchemaError("/", "HASH key must be defiened");
        if (range && !hash)
            throw new SchemaError("/", "RANGE key defined without HASH key");
        return { hash, range };
    }
}
exports.Repository = Repository;
class HashRepository extends Repository {
    load(hash) {
        return __awaiter(this, void 0, void 0, function* () {
            return this._load(hash, undefined);
        });
    }
    save(json) {
        return __awaiter(this, void 0, void 0, function* () {
            return this._save(json);
        });
    }
    delete(json) {
        return __awaiter(this, void 0, void 0, function* () {
            return this._delete(json);
        });
    }
}
exports.HashRepository = HashRepository;
class RangeRepository extends Repository {
    load(hash, range) {
        return __awaiter(this, void 0, void 0, function* () {
            return this._load(hash, range);
        });
    }
    save(json) {
        return __awaiter(this, void 0, void 0, function* () {
            return this._save(json);
        });
    }
    delete(json) {
        return __awaiter(this, void 0, void 0, function* () {
            return this._delete(json);
        });
    }
}
exports.RangeRepository = RangeRepository;
//# sourceMappingURL=dynamo.js.map