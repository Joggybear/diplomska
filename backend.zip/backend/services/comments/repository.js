"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const dynamo_1 = require("../../dynamo");
const threadSchema = {
    ThreadId: { S: { hash: true } },
    Title: { S: true },
    Content: { S: true },
    CommentCount: { N: true },
    Creator: { S: true },
    CreatorId: { S: true }
};
const commentSchema = {
    CommentId: { S: { hash: true } },
    ThreadId: { S: { range: true } },
    Content: { S: true },
    Creator: { S: true },
    CreatorId: { S: true }
};
class CommentRepository extends dynamo_1.RangeRepository {
    constructor(stage) {
        super(stage, 'Comment', commentSchema);
    }
    query(query) {
        return __awaiter(this, void 0, void 0, function* () {
            let queryIndexParams = {
                TableName: this.tableName
            };
            if (query && query.search) {
                queryIndexParams.FilterExpression = "contains(#content, :s)";
                queryIndexParams.ExpressionAttributeNames = {
                    "#content": "Content"
                };
                queryIndexParams.ExpressionAttributeValues = {
                    ":s": { S: query.search }
                };
            }
            let queryRes = yield this.db.scan(queryIndexParams).promise();
            let result = {
                query,
                items: queryRes.Items.map((item) => {
                    let comment = this.unmarshal(item);
                    return comment;
                })
            };
            return result;
        });
    }
    getLastComment(threadId) {
        return __awaiter(this, void 0, void 0, function* () {
            let queryParams = {
                TableName: this.tableName,
                IndexName: "Thread-index",
                KeyConditionExpression: "ThreadId = :threadId",
                ScanIndexForward: true,
                ExpressionAttributeValues: { ":threadId": { S: threadId } }
            };
            let queryRes = yield this.db.query(queryParams).promise();
            let comments = queryRes.Items.map((res) => {
                let comment = this.unmarshal(res);
                return comment;
            });
            comments.sort((a, b) => {
                return +new Date(b.created) - +new Date(a.created);
            });
            return comments ? comments[0] : null;
        });
    }
}
exports.CommentRepository = CommentRepository;
class ThreadRepository extends dynamo_1.HashRepository {
    constructor(stage) {
        super(stage, 'Thread', threadSchema);
    }
    onCommentChange(comment, operation, count) {
        return __awaiter(this, void 0, void 0, function* () {
            if (operation === "ADD")
                count += 1;
            else if (operation === "REMOVE")
                count -= 1;
            let updateParams = {
                TableName: this.tableName,
                Key: { ThreadId: { S: comment.threadId } },
                UpdateExpression: "SET #commentCount = :commentCount, #lastDate = :lastDate, #lastUser = :lastUser",
                ExpressionAttributeNames: {
                    "#commentCount": "CommentCount",
                    "#lastDate": "LastDate",
                    "#lastUser": "LastUser"
                },
                ExpressionAttributeValues: {
                    ":commentCount": {
                        N: count.toString()
                    },
                    ":lastDate": {
                        S: comment.created
                    },
                    ":lastUser": {
                        S: comment.creator
                    }
                },
                ReturnValues: "ALL_NEW"
            };
            let updated = yield this.db.updateItem(updateParams).promise();
            let thread = yield this.unmarshal(updated.Attributes);
            return thread;
        });
    }
}
exports.ThreadRepository = ThreadRepository;
//# sourceMappingURL=repository.js.map