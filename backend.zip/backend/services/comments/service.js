"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tyx_1 = require("tyx");
const api_1 = require("../../api");
const repository_1 = require("./repository");
let CommentService = class CommentService extends tyx_1.BaseService {
    activate() {
        return __awaiter(this, void 0, void 0, function* () {
            this.threadRepository = new repository_1.ThreadRepository(this.config.stage);
            this.commentRepository = new repository_1.CommentRepository(this.config.stage);
        });
    }
    search(query) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield this.commentRepository.query(query);
        });
    }
    overview(request) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!request.commentId)
                throw new tyx_1.BadRequest("Missing required parameter commentId");
            let comment = this.commentRepository.load(request.commentId, request.threadId);
            if (!comment)
                throw new tyx_1.NotFound(`Comment with id ${request.commentId} does not exist.`);
            return comment;
        });
    }
    create(comment) {
        return __awaiter(this, void 0, void 0, function* () {
            let thread = yield this.threadRepository.load(comment.threadId);
            if (!thread)
                throw new tyx_1.NotFound(`Thread with id ${comment.threadId} does not exist.`);
            const newComment = {
                threadId: comment.threadId,
                commentId: tyx_1.Utils.uuid(),
                content: comment.content,
                creator: comment.creator || 'Anonymous',
                creatorId: comment.creatorId,
                version: 0,
            };
            yield this.commentRepository.save(newComment);
            yield this.threadRepository.onCommentChange(newComment, 'ADD', thread.commentCount);
            return comment;
        });
    }
    update(commentId, comment) {
        return __awaiter(this, void 0, void 0, function* () {
            const commentExists = yield this.commentRepository.load(comment.commentId, comment.threadId);
            if (!commentExists)
                throw new tyx_1.NotFound(`Thread with id ${comment.commentId} does not exist.`);
            let newComment = Object.assign(comment, { version: commentExists.version, created: commentExists.created });
            newComment.creator = comment.creator || 'Anonymous';
            yield this.commentRepository.save(comment);
            return comment;
        });
    }
    delete(comment) {
        return __awaiter(this, void 0, void 0, function* () {
            let result = yield this.commentRepository.load(comment.commentId, comment.threadId);
            if (!result)
                throw new tyx_1.NotFound(`Comment with id ${comment.commentId} does not exist.`);
            yield this.commentRepository.delete(result);
            let thread = yield this.threadRepository.load(result.threadId);
            let lastComment = yield this.commentRepository.getLastComment(result.threadId);
            yield this.threadRepository.onCommentChange(lastComment || thread, 'REMOVE', thread.commentCount);
            return result;
        });
    }
};
__decorate([
    tyx_1.Inject(api_1.ConfigApi),
    __metadata("design:type", Object)
], CommentService.prototype, "config", void 0);
__decorate([
    tyx_1.Private(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], CommentService.prototype, "activate", null);
__decorate([
    tyx_1.Public(),
    tyx_1.Get('/comments', (next, ctx, call, path, query) => next(query)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], CommentService.prototype, "search", null);
__decorate([
    tyx_1.Public(),
    tyx_1.Get('/comments/{threadId}/{commentId}', (next, ctx, call, path) => next({ threadId: path.threadId, commentId: path.commentId })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], CommentService.prototype, "overview", null);
__decorate([
    tyx_1.Public(),
    tyx_1.Post('/comments', false, (next, ctx, call) => next(call.json || {})),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], CommentService.prototype, "create", null);
__decorate([
    tyx_1.Public(),
    tyx_1.Put("/comments/{threadId}/{commentId}", false, (next, ctx, call, path, query) => next(path.commentId, call.json)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], CommentService.prototype, "update", null);
__decorate([
    tyx_1.Public(),
    tyx_1.Delete("/comments/{threadId}/{commentId}", false, (next, ctx, call, path, query) => next({ threadId: path.threadId, commentId: path.commentId })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], CommentService.prototype, "delete", null);
CommentService = __decorate([
    tyx_1.Service(api_1.CommentApi)
], CommentService);
exports.CommentService = CommentService;
//# sourceMappingURL=service.js.map