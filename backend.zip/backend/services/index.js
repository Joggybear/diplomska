"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var config_1 = require("./config");
exports.ConfigService = config_1.ConfigService;
var service_1 = require("./threads/service");
exports.ThreadService = service_1.ThreadService;
var service_2 = require("./comments/service");
exports.CommentService = service_2.CommentService;
//# sourceMappingURL=index.js.map