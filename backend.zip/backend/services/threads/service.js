"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tyx_1 = require("tyx");
const api_1 = require("../../api");
const repository_1 = require("./repository");
let ThreadService = class ThreadService extends tyx_1.BaseService {
    activate() {
        return __awaiter(this, void 0, void 0, function* () {
            this.threadRepository = new repository_1.ThreadRepository(this.config.stage);
            this.commentRepository = new repository_1.CommentRepository(this.config.stage);
        });
    }
    search(query) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield this.threadRepository.query(query);
        });
    }
    overview(request) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!request.threadId)
                throw new tyx_1.BadRequest("Missing required parameter threadId");
            const thread = yield this.threadRepository.load(request.threadId);
            if (!thread)
                throw new tyx_1.NotFound(`Thread with id ${request.threadId} does not exist.`);
            const comments = yield this.commentRepository.listComments(request.threadId);
            console.log('COMMENTS = ', comments);
            const result = Object.assign(thread, { comments: comments.items });
            return result;
        });
    }
    create(thread) {
        return __awaiter(this, void 0, void 0, function* () {
            const newThread = {
                threadId: tyx_1.Utils.uuid(),
                title: thread.title,
                content: thread.content,
                creator: thread.creator || 'Anonymous',
                creatorId: thread.creatorId,
                lastDate: new Date().toISOString(),
                lastUser: thread.creator || 'Anonymous',
                version: 0,
                commentCount: 0
            };
            yield this.threadRepository.save(newThread);
            return thread;
        });
    }
    update(threadId, thread) {
        return __awaiter(this, void 0, void 0, function* () {
            const threadExists = yield this.threadRepository.load(thread.threadId);
            if (!threadExists)
                throw new tyx_1.NotFound(`Thread with id ${thread.threadId} does not exist.`);
            const newThread = Object.assign(thread, {
                commentCount: threadExists.commentCount,
                version: threadExists.version,
                created: threadExists.created,
                lastDate: threadExists.lastDate,
                lastUser: threadExists.lastUser
            });
            newThread.creator = thread.creator || 'Anonymous';
            yield this.threadRepository.save(newThread);
            return thread;
        });
    }
    delete(thread) {
        return __awaiter(this, void 0, void 0, function* () {
            let result = yield this.overview(thread);
            let comments = result.comments;
            comments.forEach((comment) => __awaiter(this, void 0, void 0, function* () {
                yield this.commentRepository.delete(comment);
            }));
            let deleteThread = Object.assign(result, { comments: undefined });
            yield this.threadRepository.delete(deleteThread);
            return result;
        });
    }
};
__decorate([
    tyx_1.Inject(api_1.ConfigApi),
    __metadata("design:type", Object)
], ThreadService.prototype, "config", void 0);
__decorate([
    tyx_1.Private(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ThreadService.prototype, "activate", null);
__decorate([
    tyx_1.Public(),
    tyx_1.Get('/threads', (next, ctx, call, path, query) => next(query)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ThreadService.prototype, "search", null);
__decorate([
    tyx_1.Public(),
    tyx_1.Get('/threads/{threadId}', (next, ctx, call, path) => next({ threadId: path.threadId })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ThreadService.prototype, "overview", null);
__decorate([
    tyx_1.Public(),
    tyx_1.Post('/threads', false, (next, ctx, call) => next(call.json || {})),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ThreadService.prototype, "create", null);
__decorate([
    tyx_1.Public(),
    tyx_1.Put("/threads/{threadId}", false, (next, ctx, call, path, query) => next(path.threadId, call.json)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ThreadService.prototype, "update", null);
__decorate([
    tyx_1.Public(),
    tyx_1.Delete("/threads/{threadId}", false, (next, ctx, call, path, query) => next({ threadId: path.threadId })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ThreadService.prototype, "delete", null);
ThreadService = __decorate([
    tyx_1.Service(api_1.ThreadApi)
], ThreadService);
exports.ThreadService = ThreadService;
//# sourceMappingURL=service.js.map