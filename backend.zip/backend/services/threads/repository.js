"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const dynamo_1 = require("../../dynamo");
const threadSchema = {
    ThreadId: { S: { hash: true } },
    Title: { S: true },
    Content: { S: true },
    CommentCount: { N: true },
    Creator: { S: true },
    LastDate: { S: true },
    LastUser: { S: true },
    CreatorId: { S: true }
};
const commentSchema = {
    CommentId: { S: { hash: true } },
    ThreadId: { S: { range: true } },
    Content: { S: true },
    Creator: { S: true },
    CreatorId: { S: true }
};
class ThreadRepository extends dynamo_1.HashRepository {
    constructor(stage) {
        super(stage, 'Thread', threadSchema);
    }
    query(query) {
        return __awaiter(this, void 0, void 0, function* () {
            let queryIndexParams = {
                TableName: this.tableName
            };
            if (query && query.search) {
                queryIndexParams.FilterExpression = "contains(#title, :s) OR contains(#content, :s)";
                queryIndexParams.ExpressionAttributeNames = {
                    "#title": "Title",
                    "#content": "Content"
                };
                queryIndexParams.ExpressionAttributeValues = {
                    ":s": { S: query.search }
                };
            }
            let queryRes = yield this.db.scan(queryIndexParams).promise();
            let threads = queryRes.Items.map((item) => {
                let thread = this.unmarshal(item);
                return thread;
            });
            threads.sort((a, b) => {
                return +new Date(a.created) - +new Date(b.created);
            });
            let result = {
                query,
                items: threads
            };
            return result;
        });
    }
}
exports.ThreadRepository = ThreadRepository;
class CommentRepository extends dynamo_1.RangeRepository {
    constructor(stage) {
        super(stage, "Comment", commentSchema);
    }
    listComments(threadId, debug) {
        return __awaiter(this, void 0, void 0, function* () {
            let queryParams = {
                TableName: this.tableName,
                IndexName: "Thread-index",
                KeyConditionExpression: "ThreadId = :threadId",
                ScanIndexForward: true,
                ExpressionAttributeValues: { ":threadId": { S: threadId } }
            };
            let queryRes = yield this.db.query(queryParams).promise();
            let comments = queryRes.Items.map((res) => {
                let comment = this.unmarshal(res);
                return comment;
            });
            comments.sort((a, b) => {
                return +new Date(a.created) - +new Date(b.created);
            });
            let result = {
                query: {
                    threadId: threadId,
                },
                items: comments
            };
            return result;
        });
    }
}
exports.CommentRepository = CommentRepository;
//# sourceMappingURL=repository.js.map